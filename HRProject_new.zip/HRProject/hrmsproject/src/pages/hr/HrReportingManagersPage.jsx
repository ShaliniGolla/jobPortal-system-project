import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../../components/Sidebar";

export default function HrReportingManagersPage() {
  const [activeTab, setActiveTab] = useState("managers");
  const [managers, setManagers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [user, setUser] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem("user")) || {};
    setUser(userData);
  }, []);

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      localStorage.removeItem("user");
      localStorage.removeItem("token");
      navigate("/login");
    }
  };

  const fetchManagers = async () => {
    setLoading(true);
    try {
      const r = await fetch("http://localhost:8080/api/reporting-managers", {
        credentials: "include",
      });
      const data = await r.json();
      setManagers(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchManagers();
  }, []);

  const loadDetails = (manager) => {
    if (selected && selected.id === manager.id) return;
    setSelected({ ...manager, loading: true });
    setDetailsLoading(true);
    fetch(`http://localhost:8080/api/reporting-managers/${manager.id}`, {
      credentials: "include",
    })
      .then((r) => r.json())
      .then((data) => setSelected(data))
      .catch((e) => {
        console.error(e);
        setSelected(null);
      })
      .finally(() => setDetailsLoading(false));
  };

  const handleDelete = async (e, manager) => {
    e.stopPropagation();
    if (
      !window.confirm(
        `Are you sure you want to remove ${manager.fullName} from Reporting Managers?`
      )
    ) {
      return;
    }

    try {
      const res = await fetch(
        `http://localhost:8080/api/reporting-managers/${manager.id}`,
        {
          method: "DELETE",
          credentials: "include",
        }
      );

      if (res.ok) {
        setManagers((prev) => prev.filter((m) => m.id !== manager.id));
        if (selected && selected.id === manager.id) {
          setSelected(null);
        }
      }
    } catch (err) {
      console.error("Error deleting manager:", err);
    }
  };

  const handleRemoveMember = async (e, memberId, memberName) => {
    e.stopPropagation();
    if (
      !window.confirm(
        `Are you sure you want to remove ${memberName} from this team?`
      )
    )
      return;

    try {
      const res = await fetch(
        `http://localhost:8080/api/reporting-managers/remove-member/${memberId}`,
        {
          method: "DELETE",
          credentials: "include",
        }
      );

      if (res.ok) {
        setSelected((prev) => ({
          ...prev,
          team: prev.team.filter((t) => t.id !== memberId),
        }));
      }
    } catch (err) {
      console.error("Error removing team member", err);
    }
  };

  const navItems = [
    {
      tab: "dashboard",
      label: "Dashboard",
      icon: (
        <svg
          className="w-5 h-5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="3" width="7" height="7"></rect>
          <rect x="14" y="3" width="7" height="7"></rect>
          <rect x="14" y="14" width="7" height="7"></rect>
          <rect x="3" y="14" width="7" height="7"></rect>
        </svg>
      ),
      to: "/hr/actions",
    },
    {
      tab: "candidates",
      label: "Candidates",
      icon: (
        <svg
          className="w-5 h-5"
          viewBox="0 0 24 24"
          fill="currentColor"
        >
          <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z" />
        </svg>
      ),
      to: "/hr/actions/candidates",
    },
    {
      tab: "managers",
      label: "Reporting Managers",
      icon: (
        <svg
          className="w-5 h-5"
          viewBox="0 0 24 24"
          fill="currentColor"
        >
          <path d="M9 7a4 4 0 118 0 4 4 0 01-8 0zM3 20a6 6 0 0112 0v1H3v-1zM17 13a4 4 0 110 8" />
        </svg>
      ),
      to: "/hr/actions/reporting-managers",
    },
    {
      tab: "leaves",
      label: "Leaves",
      icon: (
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <polyline points="10 9 9 9 8 9"></polyline>
        </svg>
      ),
      to: "/hr/actions/leaves"
    },
    {
      tab: "timesheet",
      label: "Timesheet",
      icon: (
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <polyline points="12 6 12 12 16 14"></polyline>
        </svg>
      ),
      to: "/hr/actions/timesheet"
    },
  ];

  return (
    <div className="flex h-screen w-screen bg-[#e3edf9] flex-col md:flex-row overflow-hidden font-brand text-brand-blue">
      {/* ================= SIDEBAR ================= */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        handleLogout={handleLogout}
        navItems={navItems}
      />

      {/* ================= MAIN CONTENT ================= */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Single Professional Header */}
        <header className="bg-brand-blue text-white p-6 md:px-10 flex items-center justify-between shadow-lg z-10">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-brand-yellow rounded-full flex items-center justify-center text-brand-blue shadow-inner border-2 border-white/20 overflow-hidden text-xl font-bold">
              {user.photoPath ? (
                <img src={user.photoPath} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                (user.fullName?.[0]) || "H"
              )}
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Reporting Manager</h1>
              <p className="text-xs text-white/50 uppercase tracking-[0.2em] mt-1 font-bold">
                Manager & Team Administration
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/hr/actions")}
              className="px-6 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-[11px] uppercase tracking-widest transition-all flex items-center gap-2 border border-white/10"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7" />
              </svg>
              Back
            </button>
          </div>
        </header>

        <div className="flex-1 p-4 md:p-8 space-y-6 overflow-y-auto flex flex-col">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 flex-1">
            {/* Managers List Section */}
            <div className="lg:col-span-1 flex flex-col space-y-4">
              <div className="flex items-center justify-between px-2">
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-blue/40">Directory List</h3>
                <span className="text-[10px] font-black text-brand-blue/20">{managers.length} Total</span>
              </div>

              <div className="bg-white rounded-3xl shadow-xl shadow-brand-blue/5 border border-brand-blue/5 overflow-hidden flex-1 flex flex-col">
                <div className="overflow-y-auto p-4 space-y-2 flex-1 scrollbar-hide">
                  {loading ? (
                    <div className="flex flex-col items-center justify-center h-full space-y-3 opacity-30 py-20">
                      <div className="w-8 h-8 border-2 border-brand-blue border-t-transparent rounded-full animate-spin" />
                      <p className="text-[10px] font-bold uppercase tracking-widest">Fetching Managers...</p>
                    </div>
                  ) : managers.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full space-y-2 opacity-20 py-20 italic">
                      <p className="text-sm font-bold">No managers found</p>
                    </div>
                  ) : (
                    managers.map((m) => (
                      <div
                        key={m.id}
                        onClick={() => loadDetails(m)}
                        className={`group relative cursor-pointer p-4 rounded-2xl transition-all border-2 flex items-center gap-4 ${selected && selected.id === m.id
                          ? 'bg-brand-blue border-brand-blue text-white shadow-xl shadow-brand-blue/20'
                          : 'bg-white border-transparent hover:border-brand-blue/10 hover:bg-gray-50 text-brand-blue'
                          }`}
                      >
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg shadow-sm transition-all ${selected && selected.id === m.id ? 'bg-white text-brand-blue' : 'bg-brand-blue/5 text-brand-blue/30 group-hover:bg-brand-blue group-hover:text-white'
                          }`}>
                          {(m.fullName || 'U').slice(0, 1)}
                        </div>
                        <div className="flex-1 overflow-hidden">
                          <div className="font-bold text-sm truncate">{m.fullName}</div>
                          <div className={`text-[10px] font-bold uppercase tracking-wider truncate transition-all ${selected && selected.id === m.id ? 'text-white/60' : 'text-brand-blue/40 group-hover:text-brand-blue/60'
                            }`}>
                            {m.corporateEmail || "No Email"}
                          </div>
                        </div>
                        <button
                          onClick={(e) => handleDelete(e, m)}
                          className={`p-2 rounded-lg transition-all ${selected && selected.id === m.id
                            ? 'text-white/40 hover:text-white hover:bg-white/10'
                            : 'text-brand-blue/20 hover:text-red-500 hover:bg-red-50'
                            }`}
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Management Panel Section */}
            <div className="lg:col-span-2 flex flex-col space-y-4">
              <div className="flex items-center justify-between px-2">
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-blue/40">Team Management Audit</h3>
                {selected && !selected.loading && (
                  <span className="text-[10px] font-black text-brand-blue/20">{(selected.team || []).length} Members</span>
                )}
              </div>

              <div className="bg-white rounded-[32px] shadow-2xl shadow-brand-blue/5 border border-brand-blue/5 overflow-hidden flex-1 flex flex-col relative">
                {!selected ? (
                  <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-6">
                    <div className="w-32 h-32 bg-brand-blue/[0.02] rounded-full flex items-center justify-center border-2 border-dashed border-brand-blue/5">
                      <svg className="w-12 h-12 text-brand-blue/10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-brand-blue mb-2">Team Overview</h4>
                      <p className="text-sm font-medium text-brand-blue/30 max-w-xs mx-auto uppercase tracking-widest leading-relaxed">
                        Select a reporting manager to audit their hierarchical structure
                      </p>
                    </div>
                  </div>
                ) : selected.loading || detailsLoading ? (
                  <div className="flex-1 flex flex-col items-center justify-center space-y-4">
                    <div className="w-12 h-12 border-4 border-brand-yellow border-t-transparent rounded-full animate-spin" />
                    <p className="text-[10px] font-black text-brand-blue/40 uppercase tracking-[0.3em]">Synchronizing Structure...</p>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col">
                    {/* Team List */}
                    <div className="flex-1 p-8 space-y-6 overflow-y-auto max-h-[500px] scrollbar-hide">
                      <div className="flex items-center justify-between">
                        <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-brand-blue/30">Managed Resources ({(selected.team || []).length})</h4>
                      </div>

                      {(!selected.team || selected.team.length === 0) ? (
                        <div className="py-20 text-center border-2 border-dashed border-brand-blue/5 rounded-[24px]">
                          <p className="text-xs font-bold text-brand-blue/20 uppercase tracking-widest italic">No active resources assigned</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {selected.team.filter(emp => emp.id !== selected.id).map(emp => (
                            <div key={emp.id} className="group p-5 bg-white border border-brand-blue/5 rounded-[20px] flex items-center gap-4 hover:shadow-xl hover:shadow-brand-blue/5 transition-all hover:-translate-y-0.5 card-hover">
                              <div className="w-12 h-12 bg-bg-slate rounded-xl flex items-center justify-center text-sm font-black text-brand-blue/30 group-hover:bg-brand-blue group-hover:text-white transition-colors">
                                {(emp.name || 'U').slice(0, 1)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="font-bold text-brand-blue truncate text-sm">{emp.name}</div>
                                <div className="text-[10px] font-bold text-brand-blue/40 uppercase tracking-widest truncate">{emp.corporateEmail || "Incomplete Profile"}</div>
                              </div>
                              <button
                                onClick={(e) => handleRemoveMember(e, emp.id, emp.name)}
                                className="opacity-0 group-hover:opacity-100 p-2 bg-red-50 text-red-500 rounded-lg transition-all hover:bg-red-500 hover:text-white"
                                title="Remove from team"
                              >
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>


        </div>
      </main>
    </div>
  );
}
