# Leave Management System - Visual Overview

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     HRMS APPLICATION                            │
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐    │
│  │              FRONTEND (React + Vite)                  │    │
│  │                                                        │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │         LeaveRequestPage.jsx                │    │    │
│  │  │  ✅ Balance Validation                       │    │    │
│  │  │  ✅ Date Calculation                         │    │    │
│  │  │  ✅ Toast Error Notifications               │    │    │
│  │  │  ✅ Submit Leave Request                     │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  │                        ↓                              │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │       EmployeeDashboard.jsx                 │    │    │
│  │  │  ✅ Balance Display (Casual/Sick/Earned)    │    │    │
│  │  │  ✅ Recent Leave History                     │    │    │
│  │  │  ✅ "Approved By" Column                    │    │    │
│  │  │  ✅ Status Color Coding                      │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  │                        ↓                              │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │        AdminDashboard.jsx                   │    │    │
│  │  │  ✅ Pending Leaves List                      │    │    │
│  │  │  ✅ Approve Button                           │    │    │
│  │  │  ✅ Reject Button + Reason Modal            │    │    │
│  │  │  ✅ Real-time Refresh                        │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  │                        ↓                              │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │      Toast Container (Global)               │    │    │
│  │  │  ✅ Success Notifications                    │    │    │
│  │  │  ✅ Error Notifications                      │    │    │
│  │  │  ✅ Auto-dismiss (5s)                        │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  └────────────────────────────────────────────────────────┘    │
│                        ↕ REST API                               │
│  ┌────────────────────────────────────────────────────────┐    │
│  │             BACKEND (Spring Boot)                     │    │
│  │                                                        │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │     LeaveController (9 Endpoints)           │    │    │
│  │  │  GET  /api/leaves                           │    │    │
│  │  │  GET  /api/leaves/{id}                      │    │    │
│  │  │  GET  /api/leaves/employee/{empId}         │    │    │
│  │  │  POST /api/leaves                           │    │    │
│  │  │  POST /api/leaves/{id}/approve              │    │    │
│  │  │  POST /api/leaves/{id}/reject               │    │    │
│  │  │  GET  /api/leaves/balance/{empId}          │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  │                        ↓                              │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │     LeaveService + LeaveBalanceService      │    │    │
│  │  │  ✅ Balance Validation                       │    │    │
│  │  │  ✅ Create Leave (PENDING)                  │    │    │
│  │  │  ✅ Approve & Deduct Balance                │    │    │
│  │  │  ✅ Reject & Keep Balance                   │    │    │
│  │  │  ✅ Convert to DTO                           │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  │                        ↓                              │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │   Repositories & Models                     │    │    │
│  │  │  ✅ Leave Entity                             │    │    │
│  │  │  ✅ LeaveBalance Entity                      │    │    │
│  │  │  ✅ LeaveType Enum                           │    │    │
│  │  │  ✅ LeaveStatus Enum                         │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  └────────────────────────────────────────────────────────┘    │
│                        ↕ JDBC                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │            DATABASE (MySQL)                           │    │
│  │                                                        │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │         leaves Table                        │    │    │
│  │  │  id, employee_id, start_date, end_date     │    │    │
│  │  │  leave_type, status, approved_by_id        │    │    │
│  │  │  submitted_at, reviewed_at                 │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  │                                                        │    │
│  │  ┌──────────────────────────────────────────────┐    │    │
│  │  │      leave_balances Table                   │    │    │
│  │  │  employee_id, casual_total, casual_used    │    │    │
│  │  │  sick_total, sick_used                      │    │    │
│  │  │  earned_total, earned_used                  │    │    │
│  │  └──────────────────────────────────────────────┘    │    │
│  └────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Data Flow Diagrams

### Leave Submission Flow
```
┌──────────────────────────────────────────────────────────────────┐
│                 LEAVE SUBMISSION PROCESS                         │
└──────────────────────────────────────────────────────────────────┘

Employee Dashboard
       ↓
   Click "Request Leave"
       ↓
LeaveRequestPage Opens
       ↓
   Fetch Leave Balance (GET /api/leaves/balance/{empId})
       ↓
   Display Balance Cards:
   ├─ Casual: 10 remaining
   ├─ Sick: 6 remaining
   └─ Earned: 12 remaining
       ↓
Employee Fills Form:
   ├─ Leave Type: CASUAL
   ├─ Dates: 2025-04-01 to 2025-04-03 (3 days)
   ├─ Reason: Personal
   └─ Submit Button
       ↓
Frontend Validation:
   ├─ All fields filled? ✅
   ├─ Start date before end date? ✅
   ├─ Days calculated: 3
   ├─ Available casual leaves: 10
   └─ 3 <= 10? ✅ PROCEED
       ↓
   POST /api/leaves
   Body: {
     employeeId: 1,
     startDate: "2025-04-01",
     endDate: "2025-04-03",
     leaveType: "CASUAL",
     reason: "Personal"
   }
       ↓
Backend Processing:
   ├─ Find employee: ✅ Found
   ├─ Get balance: Casual = 10
   ├─ Days: 3
   ├─ Validation: 3 <= 10? ✅
   ├─ Create Leave (PENDING):
   │  ├─ status = PENDING
   │  ├─ approvedBy = null
   │  ├─ reviewedAt = null
   │  └─ submittedAt = NOW
   └─ Save to Database
       ↓
Response:
   LeaveDTO {
     id: 5,
     status: "PENDING",
     approvedBy: null,
     ...
   }
       ↓
Frontend Toast:
   ✅ "Leave request submitted successfully!"
       ↓
Update Dashboard:
   ├─ Refresh leave history
   ├─ Show new leave with PENDING status
   └─ Balance unchanged (until approved)
```

### Leave Approval Flow
```
┌──────────────────────────────────────────────────────────────────┐
│                  LEAVE APPROVAL PROCESS                          │
└──────────────────────────────────────────────────────────────────┘

Admin Dashboard
       ↓
Navigate to "Leave Requests" Tab
       ↓
Load Pending Leaves:
   GET /api/leaves
   ↓ Filter status = PENDING
       ↓
Display Pending Leaves:
   ├─ Employee Name: John Doe
   ├─ Leave Type: CASUAL
   ├─ Dates: 01-Apr-2025 → 03-Apr-2025 (3 days)
   ├─ Reason: Personal
   └─ [Approve] [Reject]
       ↓
Click "Approve"
       ↓
   POST /api/leaves/5/approve
   Body: {
     approverId: 2  // Admin's user ID
   }
       ↓
Backend Processing:
   ├─ Find leave (id=5): ✅ Found
   ├─ Status = PENDING? ✅
   ├─ Find approver (id=2): ✅ Found (admin user)
   ├─ Update leave:
   │  ├─ status = APPROVED
   │  ├─ approvedBy = admin user object
   │  └─ reviewedAt = NOW
   ├─ Save leave
   ├─ Calculate days: 3
   ├─ Update balance:
   │  ├─ casualLeavesUsed += 3 (0 → 3)
   │  └─ casualLeavesRemaining -= 3 (10 → 7)
   └─ Save balance
       ↓
Response:
   LeaveDTO {
     status: "APPROVED",
     approvedBy: "admin",
     reviewedAt: "2026-01-21T14:30:00"
   }
       ↓
Frontend Toast:
   ✅ "Leave approved successfully!"
       ↓
Update Admin Dashboard:
   ├─ Remove from pending list
   ├─ Refresh pending count
   └─ Update stats
       ↓
Employee Sees (Auto-update):
   ├─ Status changed: PENDING → APPROVED ✅
   ├─ Balance updated: Casual 10 → 7
   ├─ "Approved By": admin (2026-01-21)
   └─ Leave can be viewed in history
```

### Leave Rejection Flow
```
┌──────────────────────────────────────────────────────────────────┐
│                  LEAVE REJECTION PROCESS                         │
└──────────────────────────────────────────────────────────────────┘

Admin Dashboard
       ↓
See Pending Leave
       ↓
Click "Reject" Button
       ↓
Modal Opens:
   ┌─────────────────────────────┐
   │  Reject Leave Request        │
   │                              │
   │  [Textarea]                  │
   │  "Enter rejection reason..." │
   │                              │
   │  [Cancel]  [Reject]         │
   └─────────────────────────────┘
       ↓
Admin Types:
   "Insufficient team coverage"
       ↓
Click "Reject" Button
       ↓
Validation:
   ├─ Reason is not empty? ✅
   └─ Proceed
       ↓
   POST /api/leaves/5/reject
   Body: {
     approverId: 2,
     reason: "Insufficient team coverage"
   }
       ↓
Backend Processing:
   ├─ Find leave (id=5): ✅ Found
   ├─ Status = PENDING? ✅
   ├─ Find approver (id=2): ✅ Found
   ├─ Update leave:
   │  ├─ status = REJECTED
   │  ├─ rejectionReason = "Insufficient team coverage"
   │  ├─ approvedBy = admin user object
   │  └─ reviewedAt = NOW
   ├─ Save leave
   ├─ ⚠️  DO NOT update balance (no days deducted)
   └─ Leave saved with rejection
       ↓
Response:
   LeaveDTO {
     status: "REJECTED",
     rejectionReason: "Insufficient team coverage",
     approvedBy: "admin",
     reviewedAt: "2026-01-21T14:35:00"
   }
       ↓
Frontend Toast:
   ✅ "Leave rejected successfully!"
       ↓
Modal Closes
       ↓
Update Admin Dashboard:
   ├─ Remove from pending list
   ├─ Refresh pending count
   └─ Update stats
       ↓
Employee Sees (Auto-update):
   ├─ Status changed: PENDING → REJECTED ❌
   ├─ Balance UNCHANGED: Casual stays at 10 ✅
   ├─ "Approved By": admin (2026-01-21)
   ├─ Can see rejection reason (if shown)
   └─ Leave appears in history as REJECTED
```

---

## 🎯 Component Interaction Map

```
┌─────────────────────────────────────────────────────────────────┐
│                      App.jsx                                    │
│                  (ToastContainer)                               │
└─────────────────────────────────────────────────────────────────┘
                    ↕ Router
           ┌────────┴────────┐
           ↓                 ↓
    ┌────────────────┐   ┌────────────────┐
    │ Employee Route │   │  Admin Route   │
    └────────────────┘   └────────────────┘
           ↓                     ↓
    ┌─────────────────────────────────────┐
    │    EmployeeDashboard                │
    │  (Shows leave stats & history)      │
    │                                     │
    │  ┌──────────────────────────────┐   │
    │  │  Stat Cards (Balance Display)│   │
    │  │  - Total: 28                 │   │
    │  │  - Casual: 10                │   │
    │  │  - Sick: 6                   │   │
    │  │  - Earned: 12                │   │
    │  └──────────────────────────────┘   │
    │           ↓                         │
    │  ┌──────────────────────────────┐   │
    │  │  Recent Leave History Table  │   │
    │  │  Columns:                    │   │
    │  │  - Type                      │   │
    │  │  - Dates                     │   │
    │  │  - Status (colored)          │   │
    │  │  - Approved By ⭐            │   │
    │  │  - Actions                   │   │
    │  └──────────────────────────────┘   │
    │           ↓                         │
    │  ┌──────────────────────────────┐   │
    │  │  "Request Leave" Button      │   │
    │  │  ↓ Opens LeaveRequestPage    │   │
    │  └──────────────────────────────┘   │
    └─────────────────────────────────────┘
           ↓
    ┌────────────────────────┐
    │  LeaveRequestPage      │
    │                        │
    │  ┌──────────────────┐  │
    │  │ Balance Display  │  │
    │  │ Casual: X        │  │
    │  │ Sick: Y          │  │
    │  │ Earned: Z        │  │
    │  └──────────────────┘  │
    │           ↓            │
    │  ┌──────────────────┐  │
    │  │  Form:           │  │
    │  │  - Leave Type    │  │
    │  │  - Start Date    │  │
    │  │  - End Date      │  │
    │  │  - Reason        │  │
    │  │  - Days (auto)   │  │
    │  │  - [Submit]      │  │
    │  └──────────────────┘  │
    │           ↓            │
    │  ┌──────────────────┐  │
    │  │  Toast Error?    │  │
    │  │  (Insufficient)  │  │
    │  └──────────────────┘  │
    │           ↓            │
    │  ┌──────────────────┐  │
    │  │  Toast Success?  │  │
    │  │  (Submitted)     │  │
    │  └──────────────────┘  │
    └────────────────────────┘

    ┌─────────────────────────────────────┐
    │    AdminDashboard                   │
    │  (Leave approval/rejection)         │
    │                                     │
    │  ┌──────────────────────────────┐   │
    │  │  Dashboard Tab               │   │
    │  │  - Stats (pending count)     │   │
    │  │  - Recent history table      │   │
    │  └──────────────────────────────┘   │
    │           ↓                         │
    │  ┌──────────────────────────────┐   │
    │  │  Leave Requests Tab          │   │
    │  │  - Pending leaves list       │   │
    │  │  - Each leave shows:         │   │
    │  │    ├─ Employee Name          │   │
    │  │    ├─ Leave Type             │   │
    │  │    ├─ Dates & Days           │   │
    │  │    ├─ Reason                 │   │
    │  │    └─ [Approve] [Reject]    │   │
    │  └──────────────────────────────┘   │
    │           ↓                         │
    │  Click [Approve] →                  │
    │    POST /api/leaves/{id}/approve    │
    │      ↓ Success Toast               │
    │      ↓ Refresh List                │
    │      ↓ Employee Sees Update        │
    │                                     │
    │  Click [Reject] →                   │
    │    ┌──────────────────────────┐    │
    │    │  Reject Reason Modal     │    │
    │    │                          │    │
    │    │  [Textarea - reason]     │    │
    │    │  [Cancel]  [Reject]     │    │
    │    └──────────────────────────┘    │
    │      ↓                             │
    │    POST /api/leaves/{id}/reject    │
    │      ↓ Success Toast               │
    │      ↓ Refresh List                │
    │      ↓ Employee Sees Update        │
    └─────────────────────────────────────┘
```

---

## 📱 UI Layout Reference

### Employee Dashboard View
```
┌─────────────────────────────────────────────────────────────┐
│ HRMS > Leave Management > Dashboard                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Leave Balance                                              │
│  ┌──────────┬──────────┬──────────┬──────────┐             │
│  │  Total   │ Casual   │  Sick    │ Earned   │             │
│  │    28    │    10    │    6     │    12    │             │
│  └──────────┴──────────┴──────────┴──────────┘             │
│                                                             │
│  Recent Leave History                                       │
│  ┌──────┬──────────────┬────────┬──────────┬──────────────┐ │
│  │ Type │ Dates        │ Status │ Appr. By │ Actions    │ │
│  ├──────┼──────────────┼────────┼──────────┼──────────────┤ │
│  │CASUAL│01-Apr → 03   │APPROVED│ admin    │           │ │
│  │      │              │  ✅    │(20 Jan) │            │ │
│  ├──────┼──────────────┼────────┼──────────┼──────────────┤ │
│  │ SICK │10-Apr → 10   │PENDING │ -        │ [Recall] │ │
│  │      │              │ ⏳     │         │          │ │
│  ├──────┼──────────────┼────────┼──────────┼──────────────┤ │
│  │EARNED│15-Apr → 16   │REJECTED│ admin    │           │ │
│  │      │              │  ❌    │(18 Jan) │            │ │
│  └──────┴──────────────┴────────┴──────────┴──────────────┘ │
│                                                             │
│  [Request Leave Button]                                     │
└─────────────────────────────────────────────────────────────┘
```

### Leave Request Form
```
┌─────────────────────────────────────────────────────────────┐
│ Request Leave                                               │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Current Balance                                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Casual: 10   │  │  Sick: 6     │  │ Earned: 12   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                             │
│  Leave Type:     [Casual ▼]                                │
│                                                             │
│  Start Date:     [2025-04-01]                              │
│                                                             │
│  End Date:       [2025-04-03]                              │
│                                                             │
│  Days:           3 days                                    │
│                                                             │
│  Available:      10 days                                   │
│                                                             │
│  Reason:         [Personal leave for vacation...]         │
│                  [                                       ] │
│                                                             │
│  [Submit] [Cancel]                                          │
│                                                             │
│  ✅ Success: Leave request submitted!                      │
│  ❌ Error: Insufficient Casual leaves                      │
└─────────────────────────────────────────────────────────────┘
```

### Admin Approval Interface
```
┌─────────────────────────────────────────────────────────────┐
│ HRMS > Admin > Leave Requests                               │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Pending Leaves (4)                                         │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ John Doe                                    [Stats]  │  │
│  │ CASUAL • 01-Apr → 03-Apr (3 days)                   │  │
│  │ Reason: Personal                                    │  │
│  │                    [Approve]  [Reject]             │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Jane Smith                                  [Stats]  │  │
│  │ SICK • 10-Apr → 11-Apr (2 days)                     │  │
│  │ Reason: Medical appointment                        │  │
│  │                    [Approve]  [Reject]             │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  [More leaves...]                                           │
│                                                             │
│  ┌─────────────────────────────────────────────────┐      │
│  │  Reject Leave Request                           │      │
│  │                                                 │      │
│  │  Enter rejection reason:                        │      │
│  │  [Insufficient team coverage for that period  ] │      │
│  │  [                                            ] │      │
│  │                                                 │      │
│  │        [Cancel]        [Reject]               │      │
│  └─────────────────────────────────────────────────┘      │
│                                                             │
│  ✅ Success: Leave approved!                               │
│  ✅ Success: Leave rejected!                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 State Management Flow

```
┌────────────────────────────────────────────────────┐
│         LeaveRequestPage State                     │
├────────────────────────────────────────────────────┤
│ useState:                                          │
│  - formData: {leaveType, startDate, endDate, ...} │
│  - loading: boolean                                │
│  - employeeId: number                              │
│  - leaveBalance: {casual, sick, earned}            │
│                                                    │
│ useEffect:                                         │
│  - Fetch balance on mount                          │
│                                                    │
│ Functions:                                         │
│  - handleInputChange()                             │
│  - fetchLeaveBalance()                             │
│  - calculateLeaveDays()                            │
│  - handleSubmit()                                  │
│                                                    │
│ Toast Events:                                      │
│  - Error: Validation failed                        │
│  - Error: Insufficient balance                     │
│  - Success: Leave submitted                        │
└────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────┐
│       EmployeeDashboard State                      │
├────────────────────────────────────────────────────┤
│ useState:                                          │
│  - leaveBalance: {casual, sick, earned}            │
│  - recentLeaves: [{...leave}, ...]                 │
│  - loading: boolean                                │
│  - error: string                                   │
│                                                    │
│ useEffect:                                         │
│  - Fetch balance on mount                          │
│  - Fetch recent leaves on mount                    │
│                                                    │
│ Functions:                                         │
│  - fetchLeaveData()                                │
│  - getStatusColor()                                │
│  - formatDate()                                    │
│  - handleRecallLeave()                             │
└────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────┐
│        AdminDashboard State                        │
├────────────────────────────────────────────────────┤
│ useState:                                          │
│  - leaveRequests: [{...leave}, ...]                │
│  - pendingLeaves: [{...leave}, ...]                │
│  - loading: boolean                                │
│  - showRejectModal: boolean                        │
│  - rejectingLeaveId: number                        │
│  - rejectReason: string                            │
│  - currentUserId: number                           │
│  - stats: {totalEmployees, pendingLeaves, ...}    │
│                                                    │
│ useEffect:                                         │
│  - Get current user ID on mount                    │
│  - Fetch leave requests on mount                   │
│                                                    │
│ Functions:                                         │
│  - fetchLeaveRequests()                            │
│  - handleApprove(id)                               │
│  - handleRejectClick(id)                           │
│  - handleRejectConfirm()                           │
│  - getStatusColor()                                │
│  - formatDate()                                    │
│  - calculateLeaveDays()                            │
│                                                    │
│ Toast Events:                                      │
│  - Success: Leave approved                         │
│  - Success: Leave rejected                         │
│  - Error: API failures                             │
└────────────────────────────────────────────────────┘
```

---

## 📡 API Request/Response Examples

### Create Leave Request
```
POST /api/leaves

Request Body:
{
  "employeeId": 1,
  "startDate": "2025-04-01",
  "endDate": "2025-04-03",
  "leaveType": "CASUAL",
  "reason": "Personal"
}

Response (200 OK):
{
  "message": "success",
  "data": {
    "id": 5,
    "employeeId": 1,
    "employeeName": "John Doe",
    "startDate": "2025-04-01",
    "endDate": "2025-04-03",
    "leaveType": "CASUAL",
    "reason": "Personal",
    "status": "PENDING",
    "approvedBy": null,
    "rejectionReason": null,
    "submittedAt": "2026-01-21T14:20:00",
    "reviewedAt": null
  }
}
```

### Approve Leave
```
POST /api/leaves/5/approve

Request Body:
{
  "approverId": 2
}

Response (200 OK):
{
  "message": "success",
  "data": {
    "id": 5,
    "status": "APPROVED",
    "approvedBy": "admin",
    "reviewedAt": "2026-01-21T14:30:00",
    ...
  }
}

Side Effects:
- LeaveBalance: casual_leaves_used: 0 → 3
- LeaveBalance: Remaining recalculated
```

### Reject Leave
```
POST /api/leaves/5/reject

Request Body:
{
  "approverId": 2,
  "reason": "Insufficient team coverage"
}

Response (200 OK):
{
  "message": "success",
  "data": {
    "id": 5,
    "status": "REJECTED",
    "rejectionReason": "Insufficient team coverage",
    "approvedBy": "admin",
    "reviewedAt": "2026-01-21T14:35:00",
    ...
  }
}

Side Effects:
- LeaveBalance: UNCHANGED (no deduction)
```

---

**This completes the visual overview of the Leave Management System!**
