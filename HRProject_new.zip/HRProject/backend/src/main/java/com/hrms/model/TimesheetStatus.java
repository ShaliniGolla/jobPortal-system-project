package com.hrms.model;

public enum TimesheetStatus {
    PENDING, APPROVED, REJECTED
}
