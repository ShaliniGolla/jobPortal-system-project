package com.hrms.model;

public enum Role {
    ADMIN, HR, REPORTING_MANAGER, EMPLOYEE
}

