package com.hrms.model;

public enum LeaveType {
    CASUAL, SICK, EARNED
}
