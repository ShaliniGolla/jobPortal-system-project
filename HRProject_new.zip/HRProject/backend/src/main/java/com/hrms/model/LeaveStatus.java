package com.hrms.model;

public enum LeaveStatus {
    PENDING, APPROVED, REJECTED
}
